namespace YogaMVC1.Models;

public class PoseMapping
{
    public int? Mapping_Id { get; set; }
    public int? Pose_Id { get; set; }
    public int? Category_Id { get; set; }
    public int? Difficulty_Id { get; set; } 
}