namespace YogaMVC1.Models;

public class CategoryDetailViewModel
{
    public Category Category { get; set; }
    public List<Pose> Poses { get; set; }
}