namespace YogaMVC1.Models;

public class Difficulty
{
    public int Difficulty_Id { get; set; }
    public string Difficulty_Level { get; set; }
}